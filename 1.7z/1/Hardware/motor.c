#include "include.h"
 
void Forward(int speed)
{  
	Set_LeftAspeed(speed);
	Set_LeftBspeed(speed);
	Set_RightAspeed(speed);
	Set_RightBspeed(speed);
}

void Backward(int speed)
{
	Set_LeftAspeed(-speed);
	Set_LeftBspeed(-speed);
	Set_RightAspeed(-speed);
	Set_RightBspeed(-speed);
}

void Leftward(int speed)
{
	Set_LeftAspeed(-speed);
	Set_LeftBspeed(speed);
	Set_RightAspeed(speed);
	Set_RightBspeed(-speed);
}

void Rightward(int speed)
{
	Set_LeftAspeed(speed);
	Set_LeftBspeed(-speed);
	Set_RightAspeed(-speed);
	Set_RightBspeed(speed);
}

void Motor_Init(void)
{
	HAL_TIM_Base_Start_IT(&htim9);
	HAL_TIM_PWM_Start(&htim5,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim5,TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim5,TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim5,TIM_CHANNEL_4);
	HAL_GPIO_WritePin(MO1_GPIO_Port,MO1_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(MO4_GPIO_Port,MO2_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(MO3_GPIO_Port,MO3_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(MO2_GPIO_Port,MO4_Pin,GPIO_PIN_RESET);
	__HAL_TIM_SET_COMPARE(&htim5,TIM_CHANNEL_1,0);
	__HAL_TIM_SET_COMPARE(&htim5,TIM_CHANNEL_2,0);
	__HAL_TIM_SET_COMPARE(&htim5,TIM_CHANNEL_3,0);
	__HAL_TIM_SET_COMPARE(&htim5,TIM_CHANNEL_4,0);
}

void Set_LeftAspeed(int speed)
{
	if(speed>100)
		speed=100;
	else if(speed<-100)
		speed=-100;
	if(speed>0)
	{
		HAL_GPIO_WritePin(MO1_GPIO_Port,MO1_Pin,GPIO_PIN_RESET);
		__HAL_TIM_SET_COMPARE(&htim5,TIM_CHANNEL_1,speed);
	}
	else
	{
		HAL_GPIO_WritePin(MO1_GPIO_Port,MO1_Pin,GPIO_PIN_SET);
		__HAL_TIM_SET_COMPARE(&htim5,TIM_CHANNEL_1,100+speed);		
	}
}

void Set_LeftBspeed(int speed)
{
	if(speed>100)
		speed=100;
	else if(speed<-100)
		speed=-100;
	if(speed>0)
	{
		HAL_GPIO_WritePin(MO2_GPIO_Port,MO2_Pin,GPIO_PIN_RESET);
		__HAL_TIM_SET_COMPARE(&htim5,TIM_CHANNEL_2,speed);
	}
	else
	{
		HAL_GPIO_WritePin(MO2_GPIO_Port,MO2_Pin,GPIO_PIN_SET);
		__HAL_TIM_SET_COMPARE(&htim5,TIM_CHANNEL_2,100+speed);		
	}
}

void Set_RightAspeed(int speed)
{
	if(speed>100)
		speed=100;
	else if(speed<-100)
		speed=-100;
	if(speed>0)
	{
		HAL_GPIO_WritePin(MO3_GPIO_Port,MO3_Pin,GPIO_PIN_RESET);
		__HAL_TIM_SET_COMPARE(&htim5,TIM_CHANNEL_3,speed);
	}
	else
	{
		HAL_GPIO_WritePin(MO3_GPIO_Port,MO3_Pin,GPIO_PIN_SET);
		__HAL_TIM_SET_COMPARE(&htim5,TIM_CHANNEL_3,100+speed);		
	}
}

void Set_RightBspeed(int speed)
{
	if(speed>100)
		speed=100;
	else if(speed<-100)
		speed=-100;
	if(speed>0)
	{
		HAL_GPIO_WritePin(MO4_GPIO_Port,MO4_Pin,GPIO_PIN_RESET);
		__HAL_TIM_SET_COMPARE(&htim5,TIM_CHANNEL_4,speed);
	}
	else
	{
		HAL_GPIO_WritePin(MO4_GPIO_Port,MO4_Pin,GPIO_PIN_SET);
		__HAL_TIM_SET_COMPARE(&htim5,TIM_CHANNEL_4,100+speed);		
	}
}

