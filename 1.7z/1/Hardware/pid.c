#include "include.h"
#include <math.h>

PID pid_yaw,pid_flowx,pid_flowy;

//һpidʷ����
void PID_Clear(PID *pid)
{
	pid->error=0;
	pid->lastError=0;
	pid->integral=0;
	pid->output=0;
}

//����pid����
void PID_SingleCalc(PID *pid,float reference,float feedback)
{
	if(pid->error==0)
		PID_Clear(pid);
	//计算误差
	pid->lastError=pid->error;
	pid->error=reference-feedback;
	
	//添加死区
	if(fabs(pid->error) < 2.0f)  // 2.0是死区大小，可以根据需要调整
	{
		pid->error = 0;
		pid->lastError = 0;
		pid->integral = 0;
		return;
	}
	
	//计算微分
	pid->output=(pid->error-pid->lastError)*pid->kd;
	//�������
	pid->output+=pid->error*pid->kp;
	//�������
	if(feedback>reference)
	{
		if(feedback-reference>pid->deviation)
		{
			pid->integral+=pid->error*pid->ki;
		}
		else
			PID_Clear(pid);
	}
	else
	{
		if(reference-feedback>pid->deviation)
		{
			pid->integral+=pid->error*pid->ki;
		}
		else
			PID_Clear(pid);
	}
	
	LIMIT(pid->integral,-pid->maxIntegral,pid->maxIntegral);//�����޷�
	pid->output+=pid->integral;
	//����޷�
	LIMIT(pid->output,-pid->maxOutput,pid->maxOutput);
}

void PID_Init(PID *pid,float p,float i,float d,float maxI,float maxOut,uint32_t Deviation)
{
	pid->kp=p;
	pid->ki=i;
	pid->kd=d;
	pid->maxIntegral=maxI;
	pid->maxOutput=maxOut;
	pid->integral=0;
	pid->deviation=Deviation;
}

