#ifndef __INCLUDE_H  //���ڴ��ͷ�ļ�
#define __INCLUDE_H


#include "main.h"
#include "string.h"
#include "math.h"
#include "stdio.h"
#include "stdarg.h"
#include "gpio.h"
#include "usart.h"
#include "tim.h"
#include "spi.h"
//#include "adc.h"

#include "key.h"
#include "k.h"
#include "oled.h"
#include "flash.h"
#include "ui.h"
#include "pid.h"
#include "w25qxx.h"
#include "motor.h"

#endif

