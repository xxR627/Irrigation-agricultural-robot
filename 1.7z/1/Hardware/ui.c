#include "include.h"

uint8_t flag_oledupdate=1;

void OLED_update(uint8_t* flag)
{
	if(*flag==1)
	{
		OLED_Clear();
		if(page==0)
		{
			OLED_ShowString(1,1,"pid",0);
			OLED_ShowString(2,1,"kp:",0);
			OLED_ShowString(3,1,"ki:",0);
			OLED_ShowString(4,1,"kd:",0);
			OLED_ShowNum(2,5,pid_yaw.kp,3,(level==0));
			OLED_ShowNum(3,5,pid_yaw.ki,3,(level==1));
			OLED_ShowNum(4,5,pid_yaw.kd,3,(level==2));

		}
		else if(page==1)
		{
			OLED_ShowString(1,1,"usart_log",0);
		}
		else if(page==2)
		{
			OLED_ShowString(1,1,"oled_log",0);	
		}
		else if(page==3)
		{
			OLED_ShowString(1,1,"distance",0);
		}
		else if(page==4)
		{
			OLED_ShowString(1,1,"wd",0);
		}
	}
	else if(*flag==2)
	{
			OLED_ShowNum(2,5,pid_yaw.kp,3,!(flag_flash||flag_edit&&(level!=0)));
			OLED_ShowNum(3,5,pid_yaw.ki,3,!(flag_flash||flag_edit&&(level!=1)));
			OLED_ShowNum(4,5,pid_yaw.kd,3,!(flag_flash||flag_edit&&(level!=2)));
	}
	
	*flag=0;
}
