#ifndef __UI_H
#define __UI_H

#include "main.h"

extern uint8_t flag_oledupdate;

void OLED_update(uint8_t* flag);

#endif

