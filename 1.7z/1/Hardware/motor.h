#ifndef __MOTOR_H
#define __MOTOR_H
#include "main.h"

void Set_RightBspeed(int speed);
void Set_RightAspeed(int speed);
void Set_LeftBspeed(int speed);
void Set_LeftAspeed(int speed);
void Forward(int speed);
void Rightward(int speed);
void Leftward(int speed);
void Backward(int speed);
void Motor_Init(void);

#endif

