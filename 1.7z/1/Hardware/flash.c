#include "include.h"

// ����ָ������
HAL_StatusTypeDef Erase_Sector(uint32_t Sector, uint8_t NbSectors) 
{
    FLASH_EraseInitTypeDef EraseInitStruct;
    uint32_t SectorError;

    EraseInitStruct.TypeErase = FLASH_TYPEERASE_SECTORS;
    EraseInitStruct.Sector = Sector;
    EraseInitStruct.NbSectors = NbSectors;
    EraseInitStruct.VoltageRange = FLASH_VOLTAGE_RANGE_3;

    if (HAL_FLASHEx_Erase(&EraseInitStruct, &SectorError) != HAL_OK) {
        return HAL_ERROR;
    }

    return HAL_OK;
}

// д�����ݵ�ָ����ַ
HAL_StatusTypeDef Write_Data(uint32_t Address, uint32_t* Data, uint16_t Size)
{    
	HAL_FLASH_Unlock();
    for (uint16_t i = 0; i < Size; i++) 
	{
        if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, Address + (i * 4), Data[i]) != HAL_OK) 
		{
            return HAL_ERROR;
        }
    }
	HAL_FLASH_Lock();
    return HAL_OK;
}

// ��ȡָ����ַ������
uint32_t Read_Data(uint32_t Address) 
{
    return (*(__IO uint32_t*)Address);
}
void Flash_init(void)
{
	
	uint32_t data[2] = {0x05,0x10};
    uint32_t address = 0x08010000;
    uint32_t sector = FLASH_SECTOR_4;
    uint8_t nb_sectors = 1;
    uint32_t read_data = Read_Data(0x08010000),read_data1=Read_Data(0x08010001);
    if(read_data!=0x05&&read_data1!=0x10)
    {
	    if (Erase_Sector(sector, nb_sectors) != HAL_OK)
	  	  printf("flash ersing error\r\n");
	    else
	  	  printf("flash ersing normally\r\n");
	    if (Write_Data(address, data, sizeof(data) / sizeof(data[0])) != HAL_OK) 
	  	  printf("flash writing error\r\n");
	    else
	  	  printf("flash writing normally\r\n");
    }
    else
	{
		printf("Password:0x05 0x10\r\n");
	    printf("flash loading normally\r\n");
	}
}

void Write_Datatoflash(uint32_t Address, uint32_t* Data)
{
    uint32_t sector = FLASH_SECTOR_5;
	uint8_t nb_sectors = 1;
	Erase_Sector(sector, nb_sectors);
	if(Write_Data(Address, Data, sizeof(Data) / sizeof(Data[0])) != HAL_OK) 
	    printf("data writing error\r\n");
}

