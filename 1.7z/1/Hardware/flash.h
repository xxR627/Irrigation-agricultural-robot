#ifndef __FLASH_H
#define __FLASH_H

#include "main.h"

void Write_Datatoflash(uint32_t Address, uint32_t* Data);
void Flash_init(void);
uint32_t Read_Data(uint32_t Address);

#endif

